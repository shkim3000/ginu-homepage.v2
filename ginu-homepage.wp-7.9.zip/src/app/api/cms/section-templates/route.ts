import { NextResponse } from "next/server";
import { loadAllTemplates } from "@/cms/templates-index";

export async function GET() {
  const templates = loadAllTemplates();
  return NextResponse.json({ templates });
}
