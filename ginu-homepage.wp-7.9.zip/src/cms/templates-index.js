import fs from "fs";
import path from "path";

export function loadAllTemplates() {
  const dir = path.join(process.cwd(), "src", "cms", "sections");

  if (!fs.existsSync(dir)) return {};

  const files = fs.readdirSync(dir).filter(f => f.endsWith(".json"));

  const templates = {};

  for (const file of files) {
    const name = file.replace(".json", "");
    const fullPath = path.join(dir, file);

    try {
      const content = JSON.parse(fs.readFileSync(fullPath, "utf8"));
      templates[name] = content;
    } catch (e) {
      console.error("Template parse error:", e);
    }
  }

  return templates;
}
