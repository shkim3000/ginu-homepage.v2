"use client";

import { useState, useEffect } from "react";
import SectionList from "../SectionList";
import TemplateSelectModal from "../TemplateSelectModal";

export default function Sidebar({
  sections,
  setSections,
  selectedIndex,
  setSelectedIndex,
}) {
  const [showTemplateModal, setShowTemplateModal] = useState(false);
  const [templateMap, setTemplateMap] = useState({});

  // ⭐ API로 template 목록 로딩
  useEffect(() => {
    fetch("/api/cms/section-templates")
      .then((res) => res.json())
      .then((data) => setTemplateMap(data.templates));
  }, []);

  function handleAddFromTemplate(templateId) {
    const template = templateMap[templateId];
    if (!template) return;

    const newId = `${templateId}_${Date.now()}`;

    const newSection = {
      id: newId,
      template: templateId,
      props: { ...template.props },
    };

    setSections([...sections, newSection]);
    setSelectedIndex(sections.length);
  }

  return (
    <div className="w-64 border-r h-full overflow-y-auto p-4 bg-gray-50">
      <h2 className="text-sm font-semibold mb-3 text-gray-600">Sections</h2>

      <SectionList
        sections={sections}
        selectedIndex={selectedIndex}
        setSelectedIndex={setSelectedIndex}
      />

      <button
        onClick={() => setShowTemplateModal(true)}
        className="w-full px-3 py-2 mt-3 rounded bg-blue-600 text-white text-sm hover:bg-blue-700"
      >
        + Add Section
      </button>

      {showTemplateModal && (
        <TemplateSelectModal
          onClose={() => setShowTemplateModal(false)}
          onSelect={(templateId) => handleAddFromTemplate(templateId)}
        />
      )}
    </div>
  );
}
