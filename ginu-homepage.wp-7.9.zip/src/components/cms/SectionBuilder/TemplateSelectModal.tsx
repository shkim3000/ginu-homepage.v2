"use client";

import { useEffect, useState } from "react";

export default function TemplateSelectModal({
  onSelect,
  onClose,
}: {
  onSelect: (templateId: string) => void;
  onClose: () => void;
}) {
  const [templates, setTemplates] = useState<Record<string, any>>({});

  useEffect(() => {
    fetch("/api/cms/section-templates")
      .then((res) => res.json())
      .then((data) => {
        setTemplates(data.templates);
      });
  }, []);

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded shadow p-6 w-96">
        <h2 className="text-lg font-semibold mb-4">Choose a Template</h2>

        <div className="flex flex-col gap-2 max-h-80 overflow-auto">
          {Object.keys(templates).map((key) => (
            <button
              key={key}
              onClick={() => {
                onSelect(key);
                onClose();
              }}
              className="p-2 border rounded hover:bg-gray-50 text-left"
            >
              {key}
            </button>
          ))}
        </div>

        <button
          onClick={onClose}
          className="mt-4 px-3 py-1 border rounded text-sm"
        >
          Close
        </button>
      </div>
    </div>
  );
}
