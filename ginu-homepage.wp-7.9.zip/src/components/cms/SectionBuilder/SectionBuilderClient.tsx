"use client";

import { useEffect, useState } from "react";
import TopBar from "./Layout/TopBar";
import Sidebar from "./Layout/Sidebar";
import BuilderMain from "./Layout/BuilderMain";

type SectionEntry = {
  id: string;
  props?: Record<string, any>;
};

type CMSPage = {
  title: string;
  layout: string;
  sections: SectionEntry[];
};

export default function SectionBuilderClient({ slug }: { slug: string }) {
  const [pageData, setPageData] = useState<CMSPage | null>(null);
  const [sections, setSections] = useState<SectionEntry[]>([]);
  const [selectedIndex, setSelectedIndex] = useState(0);

  useEffect(() => {
    fetch(`/api/cms/page/${slug}`)
      .then((res) => res.json())
      .then((data: CMSPage) => {
        setPageData(data);
        setSections(data.sections || []);
      });
  }, [slug]);

  const handleSectionChange = (
    index: number,
    key: string,
    value: any
  ) => {
    setSections((prev) => {
      const cloned = [...prev];
      const target = cloned[index] || { id: "", props: {} };

      if (!target.props) target.props = {};
      target.props[key] = value;

      cloned[index] = target;
      return cloned;
    });
  };

  if (!pageData) return <div className="p-6">Loading...</div>;

  return (
    <div className="flex flex-col h-screen overflow-hidden">
      <TopBar slug={slug} title={pageData.title} sections={sections} />

      <div className="flex flex-1 overflow-hidden">
        <Sidebar
          sections={sections}
          selectedIndex={selectedIndex}
          setSelectedIndex={setSelectedIndex}
        />

        <BuilderMain
          sections={sections}
          selectedIndex={selectedIndex}
          handleSectionChange={handleSectionChange}
        />
      </div>
    </div>
  );
}

