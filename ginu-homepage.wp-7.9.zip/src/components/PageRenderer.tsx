"use client";

import { Fragment } from "react";
import { SectionMap } from "@/components/cms/SectionRenderer";

type SectionEntry = {
  id: string;
  type: string;
  props?: Record<string, any>;
};

type CMSPage = {
  title: string;
  layout: string;
  sections: SectionEntry[];
};

/**
 * PageRenderer (sections-index.js 의존 제거)
 * ------------------------------------------------
 * - page.sections 배열에 이미 { id, type, props }가 모두 있음
 * - 따라서 SectionMap[type] 만 찾아서 렌더하면 됨
 */
export default function PageRenderer({ page }: { page: CMSPage }) {
  if (!page || !Array.isArray(page.sections)) return null;

  return (
    <Fragment>
      {page.sections.map((entry, index) => {
        const { id, type, props = {} } = entry;

        // SectionRenderer에서 직접 컴포넌트 찾음
        const Component = SectionMap[type];

        if (!Component) {
          return (
            <div
              key={id}
              className="p-4 bg-red-100 border border-red-300 text-red-700"
            >
              Missing component for section type: <b>{type}</b>
            </div>
          );
        }

        return <Component key={`${id}-${index}`} {...props} />;
      })}
    </Fragment>
  );
}
